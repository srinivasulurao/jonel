<?php /* HELPDESK $Id: vw_idx_closed.php,v 1.9 2004/05/05 16:11:51 bloaterpaste Exp $*/
require_once("vw_idx_handler.php");

// Show closed items
print vw_idx_handler(1);
?>
