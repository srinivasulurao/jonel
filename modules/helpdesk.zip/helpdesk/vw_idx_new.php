<?php /* HELPDESK $Id: vw_idx_new.php,v 1.8 2004/05/05 16:11:51 bloaterpaste Exp $*/
require_once("vw_idx_handler.php");

// Show opened items
vw_idx_handler(0);
?>
