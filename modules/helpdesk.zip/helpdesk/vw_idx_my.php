<?php /* HELPDESK $Id: vw_idx_my.php,v 1.3 2004/08/03 03:27:05 cyberhorse Exp $*/

require_once($dPconfig['root_dir'] . "/modules/helpdesk/helpdesk.functions.php");
require_once($dPconfig['root_dir'] . "/modules/helpdesk/vw_idx_handler.php");

// Show my items
vw_idx_handler(2);
?>
